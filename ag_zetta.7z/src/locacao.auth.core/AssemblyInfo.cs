﻿using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("mtgroup.auth.clientebd", AllInternalsVisible = true)]
