﻿namespace mtgroup.auth.Interfaces
{
    public interface IEntidade
    {
        int Id { get; }
    }
}