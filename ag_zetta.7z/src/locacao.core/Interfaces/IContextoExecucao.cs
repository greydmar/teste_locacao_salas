﻿using mtgroup.locacao.DataModel;

namespace mtgroup.locacao.Interfaces
{
    public interface IContextoExecucao
    {
        Solicitante Solicitante { get; }
    }
}