﻿namespace mtgroup.locacao.Interfaces
{
    public interface IEntidade
    {
        int Id { get; }

    }
}